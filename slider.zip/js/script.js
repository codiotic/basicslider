$(function() {
	var slider = $('.slider-container ul');
	var slides = $('.slider-container ul li');
	var numOfSlides = slides.length;
	var curSlide = 1; 
	var interval = '';

	function startSlider(){
	   interval = setInterval(function(){
		slider.animate({'margin-left':'-=960px'},2000);
		curSlide++;
		if(curSlide >= numOfSlides){
			slider.animate({'margin-left':'0px'},000);
			curSlide = 1;
		}
	   },3000);
	}
   startSlider();
   $('.slider-container').hover(function(){
        clearInterval(interval);
   }).mouseleave(function(){
   	   startSlider();
   })	
})